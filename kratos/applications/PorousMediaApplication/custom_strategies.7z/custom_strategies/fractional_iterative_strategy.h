/* *********************************************************
 *
 *   Last Modified by:    $Author: rrossi $
 *   Date:                $Date: 2009-01-13 15:39:56 $
 *   Revision:            $Revision: 1.14 $
 *
 * ***********************************************************/


#if !defined(KRATOS_FRACTIONAL_ITERATIVE_STRATEGY)
#define  KRATOS_FRACTIONAL_ITERATIVE_STRATEGY


/* System includes */


/* External includes */
#include "boost/smart_ptr.hpp"


/* Project includes */
#include "includes/define.h"
#include "includes/model_part.h"
#include "utilities/geometry_utilities.h"

//Inheritance
#include "solving_strategies/strategies/solving_strategy.h"

//Configuration files of Strategy (to load objects of configuration attributes to deal with Matrix)
#include "custom_strategies/solver_strategy_configuration.h"
//#include "custom_strategies/solver_configuration.h"
#include "custom_strategies/fractional_iterative_configuration.h"
//#include "custom_strategies/fractionalstep_configuration.h"


namespace Kratos
{
    
template<class TSparseSpace,
         class TDenseSpace,
         class TLinearSolver
         >
class FractionalIterativeStrategy
    : public SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver>
{
public:
    
    /** Counted pointer of ClassName */
    KRATOS_CLASS_POINTER_DEFINITION( FractionalIterativeStrategy );

    typedef SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver> BaseType;

    typedef typename BaseType::TDataType TDataType;

    typedef typename BaseType::DofsArrayType DofsArrayType; 

    typedef typename BaseType::TSystemMatrixType TSystemMatrixType;

    typedef typename BaseType::TSystemVectorType TSystemVectorType;

    typedef typename BaseType::LocalSystemVectorType LocalSystemVectorType;

    typedef typename BaseType::LocalSystemMatrixType LocalSystemMatrixType;
    
    
    /*
     * From incompresible_fluid_application/ strategies/ custom_strategies/ fractional_step_streategy.h 
     */
    
    //Doc-> constructor
    FractionalIterativeStrategy(
    ModelPart& model_part,
    SolverStrategyConfiguration<TSparseSpace, TDenseSpace, TLinearSolver>& aSolverStrategyConfiguration,
    bool aReformDofAtEachIteration = true,
    double aPressureTol = 0.00001,
    double aConcentrationTol = 0.0000001,
    int aMaxIterPressure = 12,
    int aMaxIterConcentration = 12,
    unsigned int aTimeOrder = 1,
    unsigned int aDomainSize = 2,
    bool aPredictorCorrector = false,
    bool aMoveMeshFlag = false, 
    unsigned int aEchoLevel = 3
    )
        : SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver>(model_part, aMoveMeshFlag), mSolverStrategyConfiguration(aSolverStrategyConfiguration)
    {
        KRATOS_TRY

        this->mPressureTol = aPressureTol;
        this->mConcentrationTol = aConcentrationTol;
        this->mMaxIterPressure = aMaxIterPressure;
        this->mMaxIterConcentration = aMaxIterConcentration;
        this->mPredictorOrder = aTimeOrder;
        this->mTimeOrder = aTimeOrder;
        this->mDomainSize = aDomainSize;
        this->mPredictorCorrector = aPredictorCorrector;
        this->mReformDofAtEachIteration = aReformDofAtEachIteration;
        this->mEchoLevel = aEchoLevel;  
        
        //performs checks to verify the quality of the input
        this->Check();

        ProcessInfo& CurrentProcessInfo = model_part.GetProcessInfo();
        
        //initialize strategy (Matriz management??)
        CurrentProcessInfo[FRACTIONAL_STEP] = 1;
        this->mPressureStrategy = mSolverStrategyConfiguration.pGetStrategy(std::string("PressureStrategy"));
        CurrentProcessInfo[FRACTIONAL_STEP] = 2;
        this->mConcentrationStrategy = mSolverStrategyConfiguration.pGetStrategy(std::string("ConcentrationStrategy"));
        
        //Doc -> fijar number step
        this->mStep = 1;

        KRATOS_CATCH("")
    }

    virtual ~FractionalIterativeStrategy()
    {
        
    }

    double Solve()
    {
        KRATOS_TRY
        
        Timer::Start("solve");
        
        //Initial Guess, if not is by default method
        //Predict();
        
        //
        
        //mCalculateNormDxFlag = false;
        double Dp_norm = 0.0;
        //Doc -> assign the correct fractional step coefficients (BDF_COEFFICIENTS..)
        //by now, empty
        InitializeFractionalStep(this->mStep, this->mTimeOrder);
        
        //Doc -> initial guess for velocity from interpolation from timestep before velocity
        //by now, empty
        PredictSV(this->mStep, this->mPredictorOrder);

        //Doc -> Save old iteration to compare in convergence with the new pressure iteration. Save always that repit iterations.
        //Assign Velocity To Fract Step Velocity and Node Area to Zero
        AssignInitialStepValues();

        // Loop convergence
        
        double iteration = 1; 
        bool isGlobalConverged = false;
        //solve for fractional step velocities
        while (!isGlobalConverged)
        {
            //perform one iteration over Pressure and concentration
            //if (rank == 0)
            std::cout << "it = " << iteration  << std::endl;
            
            if(this->mEchoLevel == 3)
                std::cout << "FLOW EQUATION SOLVE: "  << std::endl;
            
            double pressureNormDx = iterationPressure();
            
            this->StorageOldSPressIteration();
            
            std::cout << "Pressure norm = " << pressureNormDx  << std::endl;
            
            //calculateAtPointAndBalance();
            
            if(this->mEchoLevel == 3)
                std::cout << "TRANSPORT EQUATION SOLVE: "   << std::endl;
            
            double concentrationNormDx = iterationConcentration();
            
            this->StorageOldSConcIteration();
            
            std::cout << "Concentration norm = " << concentrationNormDx  << std::endl;
            
            if( isConverged() )
                isGlobalConverged = true;
            
            iteration++;
            
            if( iteration > this->mMaxIterPressure || iteration > this->mMaxIterConcentration)
            {
                std::cout << "ATTENTION: convergence NOT achieved iteration  " << iteration << " reached" << std::endl;
                break;
            }
            
        }

        if (this->mReformDofAtEachIteration == true)
            this->Clear();

        //Doc -> timeStep+1
        this->mStep += 1;
        Timer::Stop("solve");
        
        return 0.0;
        
        KRATOS_CATCH("")
    }
    
    void calculateAtPointAndBalance()
    {
        /*
        ProcessInfo& rCurrentProcessInfo = BaseType::GetModelPart().GetProcessInfo();
        
        rCurrentProcessInfo[FRACTIONAL_STEP] = 2;

        Vector rhs(this->mDomainSize+1);
        Matrix lhs(this->mDomainSize+1,this->mDomainSize+1);

            //#pragma omp parallel for firstprivate(rhs,lhs)
        for(int i=0; i<static_cast<int>(BaseType::GetModelPart().Elements().size()); i++)
        {
                ModelPart::ElementsContainerType::iterator it = BaseType::GetModelPart().ElementsBegin()+i;

                it->CalculateLocalSystem(lhs,rhs,rCurrentProcessInfo);
        }
        */
    }
    
    double iterationPressure()
    {
        KRATOS_TRY

        ProcessInfo& rCurrentProcessInfo = BaseType::GetModelPart().GetProcessInfo();

        rCurrentProcessInfo[FRACTIONAL_STEP] = 1;

        //int solstep = pCurrentProcessInfo.GetCurrentSolutionStep();
        //DofsArrayType& rDofSet = mSolverStrategyConfiguration.pGetBuildAndSolve(rCurrentProcessInfo)->GetDofSet();
       
        mSolverStrategyConfiguration.pSetUpDof(rCurrentProcessInfo);
        
        double normDx = this->mPressureStrategy->Solve();
        
        return normDx;

        KRATOS_CATCH("");
    }
    
   double iterationConcentration()
    {
        KRATOS_TRY

        ProcessInfo& rCurrentProcessInfo = BaseType::GetModelPart().GetProcessInfo();

        rCurrentProcessInfo[FRACTIONAL_STEP] = 2;
        
        mSolverStrategyConfiguration.pSetUpDof(rCurrentProcessInfo);
        
        double normDx = this->mConcentrationStrategy->Solve();
        
        return normDx;

        KRATOS_CATCH("");
    }
    
    void StorageOldSPressIteration()
    {
        KRATOS_TRY

        for (ModelPart::NodeIterator i = BaseType::GetModelPart().NodesBegin();
                i != BaseType::GetModelPart().NodesEnd(); ++i)
        {
            //setting the old value of the pressure & concentration to the current one
            const double p = (i)->FastGetSolutionStepValue(PRESSURE);
            (i)->FastGetSolutionStepValue(PRESSURE_OLD_IT) = p;
     
        }

        KRATOS_CATCH("")
    }
    
        void StorageOldSConcIteration()
    {
        KRATOS_TRY

        for (ModelPart::NodeIterator i = BaseType::GetModelPart().NodesBegin();
                i != BaseType::GetModelPart().NodesEnd(); ++i)
        {
            const double c = (i)->FastGetSolutionStepValue(CONCENTRATION);
            (i)->FastGetSolutionStepValue(a/*CONCENTRATION_OLD_IT*/ ) = c;
                
        }

        KRATOS_CATCH("")
    }
    
    virtual bool isConverged()
    {
        KRATOS_TRY;
        
        double maxUpdatePressure = 0.0;
        double maxUpdateConcentration = 0.0;

        for (ModelPart::NodeIterator i = BaseType::GetModelPart().NodesBegin();
                i != BaseType::GetModelPart().NodesEnd(); ++i)
        {
            double oldIter = (i)->FastGetSolutionStepValue(PRESSURE_OLD_IT);
            double newIter = (i)->FastGetSolutionStepValue(PRESSURE);
                
            if(abs (oldIter - newIter) >= maxUpdatePressure )
                maxUpdatePressure = abs (oldIter - newIter);
                
            oldIter = (i)->FastGetSolutionStepValue(a /*CONCENTRATION_OLD_IT*/);
            newIter = (i)->FastGetSolutionStepValue(CONCENTRATION);
                
            if(abs (oldIter - newIter) >= maxUpdateConcentration )
                maxUpdateConcentration = abs (oldIter - newIter);
                
        }
        
       
        if(maxUpdatePressure < this->mPressureTol && maxUpdateConcentration < this->mConcentrationTol )
        {
            std::cout << "convergence achieved" << std::endl;
            return true;
        }
        
        std::cout << "Pressure max diffrence between iterations = " << maxUpdatePressure << std::endl;
        std::cout << "Concentration max diffrence between iterations = " << maxUpdateConcentration << std::endl;
        
        return false;
        
         KRATOS_CATCH("")
        
    }
    
    virtual void SetEchoLevel(int Level)
    {
        mEchoLevel = Level;
        mPressureStrategy->SetEchoLevel(Level);
        mConcentrationStrategy->SetEchoLevel(Level);
    }
    
    //Dubbio  
    virtual double GetStageResidualNorm(unsigned int step)
    {
        /*
        if (step <= 3)
            return this->mPressureStrategy->GetResidualNorm();
        if (step == 4)
            return this->mConcentrationStrategy->GetResidualNorm();
        else
         */
        
        return 0.0;
    }
    
    virtual void Clear()
    {
        KRATOS_WATCH("FractionalIterativeStrategy Clear Function called");  
        this->mPressureStrategy->Clear();
        this->mConcentrationStrategy->Clear();
    }
   
    virtual int Check()
    {
        KRATOS_TRY

        
        //veryfying that the model part has all the variables needed
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(PRESSURE) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----PRESSURE---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(CONCENTRATION) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----CONCENTRATION---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(PRESSURE_OLD_IT) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----PRESSURE_OLD_IT---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(a) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----a---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(PRESSURE_OLD_IT) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----PRESSURE_OLD_IT---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(DENSITY) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----DENSITY---- variable!!!!!! ERROR", "");
        
        
        //check that the domain size is correctly prescribed
        if (this->mDomainSize != mSolverStrategyConfiguration.GetDomainSize())
            KRATOS_ERROR(std::logic_error, "domain size not coinciding", "")

            //verify buffer size
            if (BaseType::GetModelPart().GetBufferSize() < mTimeOrder + 1)
                KRATOS_ERROR(std::logic_error, "insufficient buffer size. Buffer size should be >= time_order+1", "");

        //check that, in the 2D case, the xy plane is used.
        if (this->mDomainSize == 2)
        {
            double zmin = BaseType::GetModelPart().NodesBegin()->Z();
            double zmax = zmin;
            for (ModelPart::NodeIterator i = BaseType::GetModelPart().NodesBegin();
                    i != BaseType::GetModelPart().NodesEnd(); ++i)
            {
                if (i->Z() < zmin) zmin = i->Z();
                else if (i->Z() > zmax) zmax = i->Z();
            }
            if (fabs(zmax - zmin) > 1e-20)
                KRATOS_ERROR(std::logic_error, "2D model is not in the XY plane!", "")
        }

            const char ElementName[] = "FlowPressureTrans2D";
            Element const& ref_el = KratosComponents<Element>::Get(ElementName);

            for (ModelPart::ElementsContainerType::iterator it = BaseType::GetModelPart().ElementsBegin();
                    it != BaseType::GetModelPart().ElementsEnd(); ++it)
            {
                if (it->Id() < 1)
                    KRATOS_ERROR(std::logic_error, "Element Id can not be lesser than 1 (0 is not allowed as Id)", "");
                if (typeid (ref_el) != typeid (*it))
                {
                    std::cout << "wrong element found --> " << it->Id() << std::endl;
                    KRATOS_ERROR(std::logic_error, "Fractional step strategy requires FlowPressureTrans2D element for the 2D case", "");
                }
                it->Check(BaseType::GetModelPart().GetProcessInfo());
            }

        return 0;
        
        
        KRATOS_CATCH("")
    }
    
    void InitializeFractionalStep(const int aStep, const int aTimeOrder)
    {
        KRATOS_TRY;
        
        KRATOS_CATCH("");
    }
    
    void AssignInitialStepValues() 
    {
        KRATOS_TRY
       
        
        KRATOS_CATCH("");
    }
    
    void PredictSV(int step, int prediction_order)
    {
        KRATOS_TRY
 
        KRATOS_CATCH("");
    }
    
protected:
    
    typename BaseType::Pointer mPressureStrategy; 
    typename BaseType::Pointer mConcentrationStrategy; 

    double mPressureTol; 
    double mConcentrationTol;
    int mMaxIterPressure; 
    int mMaxIterConcentration; 
    unsigned int mTimeOrder;
    unsigned int mPredictorOrder; 
    bool mPredictorCorrector; 
    bool mReformDofAtEachIteration;
    int mEchoLevel; 

private:    
    //Dubbio
    unsigned int mStep;
    unsigned int mDomainSize; 
    
    //Doc -> mSolverConfigAttribute    
    SolverStrategyConfiguration<TSparseSpace, TDenseSpace, TLinearSolver>& mSolverStrategyConfiguration;

    FractionalIterativeStrategy(const FractionalIterativeStrategy& Other);

}; /* Class FractionalIterativeStrategy */

} /* namespace Kratos.*/

#endif /* KRATOS_FRACTIONAL_ITERATIVE_STRATEGY  defined */

