#if !defined(KRATOS_SOLVER_STRATEGY_CONFIGURATION )
#define  KRATOS_SOLVER_STRATEGY_CONFIGURATION


/* System includes */


/* External includes */
#include "boost/smart_ptr.hpp"


/* Project includes */
#include "includes/define.h"
#include "includes/model_part.h"
#include "solving_strategies/strategies/solving_strategy.h"


namespace Kratos
{


template<class TSparseSpace,
         class TDenseSpace,
         class TLinearSolver
         >
class SolverStrategyConfiguration
{
public:

    /** Constructor.
    */
    SolverStrategyConfiguration(ModelPart& model_part, unsigned int domain_size)
        : mrModelPart(model_part), mDomainSize(domain_size)
    {
    }

    /** Destructor.
    */

    unsigned int GetDomainSize()
    {
        return this->mDomainSize;
    }

    virtual typename SolvingStrategy<TSparseSpace,TDenseSpace,TLinearSolver>::Pointer pGetStrategy(const std::string& strategy_name )
    {
        KRATOS_ERROR(std::logic_error,"accessing to the SolverStrategyConfiguration base class","");
    }
    
protected:

    ModelPart& mrModelPart;
    unsigned int mDomainSize;

private:
    /** Copy constructor.
    */


}; /* Class FractionalStepStrategy */


}  /* namespace Kratos.*/

#endif /* KRATOS_SOLVER_STRATEGY_CONFIGURATION  defined */
