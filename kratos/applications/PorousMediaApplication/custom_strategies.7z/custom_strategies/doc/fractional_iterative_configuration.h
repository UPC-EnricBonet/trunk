#if !defined(KRATOS_FRACTIONAL_ITERATIVE_CONFIGURATION )
#define  KRATOS_FRACTIONAL_ITERATIVE_CONFIGURATION


/* System includes */


/* External includes */
#include "boost/smart_ptr.hpp"


/* Project includes */
#include "includes/define.h"
#include "includes/model_part.h"
#include "solving_strategies/strategies/solving_strategy.h"
#include "solving_strategies/strategies/residualbased_linear_strategy.h"

//#include "solving_strategies/builder_and_solvers/residualbased_elimination_builder_and_solver_slip.h"
//#include "custom_strategies/builder_and_solvers/residualbased_elimination_discretelaplacian_builder_and_solver.h"
//#include "custom_strategies/builder_and_solvers/residualbased_elimination_discretelaplacian_builder_and_solver_flexiblefsi.h"

#include "solving_strategies/schemes/residualbased_incrementalupdate_static_scheme.h"


namespace Kratos
{

template<class TSparseSpace,
         class TDenseSpace,
         class TLinearSolver
         >
class FractionalIterativeConfiguration : public SolverStrategyConfiguration<TSparseSpace, TDenseSpace, TLinearSolver>
{
public:

    /*
     * From incompresible_fluid_application/ strategies/ custom_strategies/ fractional_iterative_configuration.h 
     */
    
    FractionalIterativeConfiguration(ModelPart& model_part,
                                typename TLinearSolver::Pointer pNewPressureLinearSolver,
                                typename TLinearSolver::Pointer pNewConcentrationLinearSolver,
                                unsigned int mDomainSize
                               )
        : SolverStrategyConfiguration<TSparseSpace, TDenseSpace, TLinearSolver>(model_part, mDomainSize)
    {

        bool CalculateReactions = false;
        bool CalculateNormDxFlag = true;
        bool ReformDofAtEachIteration = false;

        typedef typename BuilderAndSolver<TSparseSpace, TDenseSpace, TLinearSolver>::Pointer BuilderSolverTypePointer;
        typedef SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver> BaseType;

        //initializing fractional velocity solution step
        typedef Scheme< TSparseSpace, TDenseSpace > SchemeType;
        typename SchemeType::Pointer pscheme = typename SchemeType::Pointer
                                               (new ResidualBasedIncrementalUpdateStaticScheme< TSparseSpace, TDenseSpace > ());


        typedef typename BuilderAndSolver<TSparseSpace,TDenseSpace,TLinearSolver>::Pointer BuilderSolverTypePointer;

        BuilderSolverTypePointer pressureBuild = BuilderSolverTypePointer(new	ResidualBasedEliminationBuilderAndSolver<TSparseSpace,TDenseSpace,TLinearSolver > (pNewPressureLinearSolver) );
        this->mPressureStrategy = typename BaseType::Pointer( new ResidualBasedLinearStrategy<TSparseSpace,  TDenseSpace, TLinearSolver > 				(model_part,pscheme,pNewPressureLinearSolver,pressureBuild,CalculateReactions,ReformDofAtEachIteration,CalculateNormDxFlag)  );
        this->mPressureStrategy->SetEchoLevel(2);
        

        BuilderSolverTypePointer concentrationBuild = BuilderSolverTypePointer(new	ResidualBasedEliminationBuilderAndSolver<TSparseSpace,TDenseSpace,TLinearSolver > (pNewPressureLinearSolver) );
        this->mConcentrationStrategy = typename BaseType::Pointer( new ResidualBasedLinearStrategy<TSparseSpace,  TDenseSpace, TLinearSolver > 				(model_part,pscheme,pNewConcentrationLinearSolver,concentrationBuild,CalculateReactions,ReformDofAtEachIteration,CalculateNormDxFlag)  );
        this->mConcentrationStrategy->SetEchoLevel(2);    

    }


    typename SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver>::Pointer pGetStrategy(const std::string& strategy_name)
    {
        KRATOS_TRY

        if (strategy_name == std::string("PressureStrategy"))
            return mPressureStrategy;
        else if (strategy_name == std::string("ConcentrationStrategy"))
            return mConcentrationStrategy;
        else
            KRATOS_ERROR(std::invalid_argument, "trying to get an inexisting strategy", "");

        KRATOS_CATCH("")
    }


protected:


private:

    typename SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver>::Pointer mPressureStrategy;
    typename SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver>::Pointer mConcentrationStrategy;


}; /* Class FractionalStepStrategy */

} /* namespace Kratos.*/

#endif /* KRATOS_FRACTIONAL_ITERATIVE_CONFIGURATION  defined */
