/* *********************************************************
 *
 *   Last Modified by:    $Author: rrossi $
 *   Date:                $Date: 2009-01-13 15:39:56 $
 *   Revision:            $Revision: 1.14 $
 *
 * ***********************************************************/


#if !defined(KRATOS_FRACTIONAL_ITERATIVE_STRATEGY)
#define  KRATOS_FRACTIONAL_ITERATIVE_STRATEGY


/* System includes */


/* External includes */
#include "boost/smart_ptr.hpp"


/* Project includes */
#include "includes/define.h"
#include "includes/model_part.h"
#include "utilities/geometry_utilities.h"

//Inheritance
#include "solving_strategies/strategies/solving_strategy.h"

//Configuration files of Strategy (to load objects of configuration attributes to deal with Matrix)
#include "custom_strategies/solver_strategy_configuration.h"
//#include "custom_strategies/solver_configuration.h"
#include "custom_strategies/fractional_iterative_configuration.h"
//#include "custom_strategies/fractionalstep_configuration.h"


namespace Kratos
{
    
template<class TSparseSpace,
         class TDenseSpace,
         class TLinearSolver
         >
class FractionalIterativeStrategy
    : public SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver>
{
public:
    
    /** Counted pointer of ClassName */
    KRATOS_CLASS_POINTER_DEFINITION( FractionalIterativeStrategy );

    typedef SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver> BaseType;

    typedef typename BaseType::TDataType TDataType;

    typedef typename BaseType::DofsArrayType DofsArrayType;

    typedef typename BaseType::TSystemMatrixType TSystemMatrixType;

    typedef typename BaseType::TSystemVectorType TSystemVectorType;

    typedef typename BaseType::LocalSystemVectorType LocalSystemVectorType;

    typedef typename BaseType::LocalSystemMatrixType LocalSystemMatrixType;
    
    /*
     * From incompresible_fluid_application/ strategies/ custom_strategies/ fractional_step_streategy.h 
     */
    
    //Doc-> constructor
    FractionalIterativeStrategy(
    ModelPart& model_part,
    SolverStrategyConfiguration<TSparseSpace, TDenseSpace, TLinearSolver>& aSolverStrategyConfiguration,
    bool aReformDofAtEachIteration = true,
    double aPressureTol = 0.01,
    double aConcentrationTol = 0.01,
    int aMaxIterPressure = 3,
    int aMaxIterConcentration = 1,
    unsigned int aTimeOrder = 2,
    unsigned int aDomainSize = 2,
    bool aPredictorCorrector = false,
    bool aMoveMesh = false, 
    unsigned int aEchoLevel = 1
    )
        : SolvingStrategy<TSparseSpace, TDenseSpace, TLinearSolver>(model_part, aMoveMesh), mSolverStrategyConfiguration(aSolverStrategyConfiguration)
    {
        KRATOS_TRY

        this->mPressureTol = aPressureTol;
        this->mConcentrationTol = aConcentrationTol;
        this->mMaxIterPressure = aMaxIterPressure;
        this->mMaxIterConcentration = aMaxIterConcentration;
        this->mPredictorOrder = aTimeOrder;
        this->mTimeOrder = aTimeOrder;
        this->mDomainSize = aDomainSize;
        this->mPredictorCorrector = aPredictorCorrector;
        this->mReformDofAtEachIteration = aReformDofAtEachIteration;
        this->mEchoLevel = aEchoLevel;  
        
        //performs checks to verify the quality of the input
        this->Check();

        //initialize strategy (Matriz management??)
        this->mPressureStrategy = mSolverStrategyConfiguration.pGetStrategy(std::string("PressureStrategy"));
        this->mConcentrationStrategy = mSolverStrategyConfiguration.pGetStrategy(std::string("ConcentrationStrategy"));
        
        //Doc -> fijar number step
        this->mStep = 1;

        KRATOS_CATCH("")
    }

    virtual ~FractionalIterativeStrategy()
    {
        
    }

    double Solve()
    {
        KRATOS_TRY
        
        Timer::Start("solve");
        
        //mCalculateNormDxFlag = false;
        double Dp_norm = 0.0;
        //Doc -> assign the correct fractional step coefficients (BDF_COEFFICIENTS..)
        //by now, empty
        InitializeFractionalStep(this->mStep, this->mTimeOrder);
        
        //Doc -> initial guess for velocity from interpolation from timestep before velocity
        //by now, empty
        PredictVelocity(this->mStep, this->mPredictorOrder);

        //Doc -> Save old iteration to compare in convergence with the new pressure iteration. Save always that repit iterations.
        //Assign Velocity To Fract Step Velocity and Node Area to Zero
        AssignInitialStepValues();

        // Loop convergence
        
        double iteration = 1;
        double OldPressureNorm = 0.0;
        bool isConvergedPressure = false;
        double OldConcentrationNorm = 0.0;
        bool isConvergedConcentration = false;
        
        bool isConverged = false;
        
        //solve for fractional step velocities
        while (isConverged == false)
        {
            //perform one iteration over Pressure and concentration
            //if (rank == 0)
            std::cout << "it = " << iteration  << std::endl;
            
            OldPressureNorm = CalculateOldPressureIteration();
            isConvergedPressure = PressureHasConverged(this->mPressureTol, OldPressureNorm); 
            
            OldConcentrationNorm = CalculateOldConcentrationIteration(); 
            isConvergedConcentration = ConcentrationHasConverged(this->mConcentrationTol, OldConcentrationNorm);
            
            if(isConvergedPressure == true && isConvergedConcentration == true)
                isConverged = true;
            
            iteration++;
            if( iteration < this->mMaxIterPressure || iteration < this->mMaxIterConcentration)
            {
                std::cout << "ATTENTION: convergence NOT achieved" << std::endl;
                break;
            }
            
        }

        if (this->mReformDofAtEachIteration == true)
            this->Clear();

        //Doc -> timeStep+1
        this->mStep += 1;
        Timer::Stop("solve");
        
        return Dp_norm;
        
        KRATOS_CATCH("")
    }

    bool PressureHasConverged (const double aPressureTolerance, double aOldPressureIterNorm)
    {
            double normDx = iterationPressure();
            std::cout << "Pressure norm = " << normDx  << std::endl;
            return ConvergenceCheck(normDx, aPressureTolerance, aOldPressureIterNorm);
    }
    
    double iterationPressure()
    {
        KRATOS_TRY

        ProcessInfo& rCurrentProcessInfo = BaseType::GetModelPart().GetProcessInfo();

        rCurrentProcessInfo[FRACTIONAL_STEP] = 0;
        
        double normDx = this->mPressureStrategy->Solve();
        
        return normDx;

        KRATOS_CATCH("");
    }
    
    bool ConcentrationHasConverged (const double aConcentrationTolerance, double aOldConcentrationIterNorm)
    {
            double normDx = iterationConcentration();
            std::cout << "Concentration norm = " << normDx  << std::endl;
            return ConvergenceCheck(normDx, aConcentrationTolerance, aOldConcentrationIterNorm);
    }
    
   double iterationConcentration()
    {
        KRATOS_TRY

        ProcessInfo& rCurrentProcessInfo = BaseType::GetModelPart().GetProcessInfo();

        rCurrentProcessInfo[FRACTIONAL_STEP] = 1;
        
        double normDx = this->mConcentrationStrategy->Solve();
        
        return normDx;

        KRATOS_CATCH("");
    }
    
    double CalculateOldPressureIteration()
    {
        KRATOS_TRY

        double local_p_norm = 0.0;
        for (ModelPart::NodeIterator i = BaseType::GetModelPart().NodesBegin();
                i != BaseType::GetModelPart().NodesEnd(); ++i)
        {
            //setting the old value of the pressure to the current one
            const double& p = (i)->FastGetSolutionStepValue(PRESSURE);
            (i)->FastGetSolutionStepValue(PRESSURE_OLD_IT) = p;

            local_p_norm += p*p;
        }

        double p_norm = BaseType::GetModelPart().GetCommunicator().SumAll(local_p_norm);

        //TODO: prepare for parallelization
        p_norm = sqrt(p_norm);

        return p_norm;
        KRATOS_CATCH("")
    }

    double CalculateOldConcentrationIteration() //double SavePressureIteration()
    {
        KRATOS_TRY

        double local_c_norm = 0.0;
        for (ModelPart::NodeIterator i = BaseType::GetModelPart().NodesBegin();
                i != BaseType::GetModelPart().NodesEnd(); ++i)
        {
            //setting the old value of the pressure to the current one
            const double& c = (i)->FastGetSolutionStepValue(CONCENTRATION);
            (i)->FastGetSolutionStepValue(a/*CONCENTRATION_OLD_IT*/ ) = c;

            local_c_norm += c*c;
        }

        double c_norm = BaseType::GetModelPart().GetCommunicator().SumAll(local_c_norm);

        //TODO: prepare for parallelization
        c_norm = sqrt(c_norm);

        return c_norm;
        
        KRATOS_CATCH("")
    }
    
    bool ConvergenceCheck(const double aNormDx, double tol, const double aOldItNorm)
    {
        KRATOS_TRY;
        
        //Dubbio
        /*
        if (fabs(aOldItNorm) > 1e-10)
            aNormDx /= aOldItNorm;
        else
            aNormDx = 1.0;
        */
        
       double ratio = aNormDx / aOldItNorm;
       
       std::cout << "Sv ratio = " << ratio << std::endl;
       
        if (ratio < tol)
        {
            //if (rank == 0) std::cout << "convergence achieved" << std::endl;
            std::cout << "convergence achieved" << std::endl;
            return true;
        }

        return false;
        
         KRATOS_CATCH("")
        
    }
    
    virtual void SetEchoLevel(int Level)
    {
        mEchoLevel = Level;
        mPressureStrategy->SetEchoLevel(Level);
        mConcentrationStrategy->SetEchoLevel(Level);
    }
    
    //Dubbio  
    virtual double GetStageResidualNorm(unsigned int step)
    {
        /*
        if (step <= 3)
            return this->mPressureStrategy->GetResidualNorm();
        if (step == 4)
            return this->mConcentrationStrategy->GetResidualNorm();
        else
         */
        
        return 0.0;
    }
    
    virtual void Clear()
    {
        KRATOS_WATCH("FractionalIterativeStrategy Clear Function called");  
        this->mPressureStrategy->Clear();
        this->mConcentrationStrategy->Clear();
    }
   
    virtual int Check()
    {
        KRATOS_TRY

        /*
        //veryfying that the model part has all the variables needed
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(FRACT_VEL) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----FRACT_VEL---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(VELOCITY) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----VELOCITY---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(MESH_VELOCITY) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----MESH_VELOCITY---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(PRESSURE) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----PRESSURE---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(PRESSURE_OLD_IT) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----PRESSURE_OLD_IT---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(PRESS_PROJ) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----PRESS_PROJ---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(CONV_PROJ) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----CONV_PROJ---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(NODAL_MASS) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----NODAL_MASS---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(BODY_FORCE) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----BODY_FORCE---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(DENSITY) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----DENSITY---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(VISCOSITY) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----VISCOSITY---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(IS_STRUCTURE) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----IS_STRUCTURE---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(EXTERNAL_PRESSURE) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----EXTERNAL_PRESSURE---- variable!!!!!! ERROR", "");
        if (BaseType::GetModelPart().NodesBegin()->SolutionStepsDataHas(IS_INTERFACE) == false)
            KRATOS_ERROR(std::logic_error, "Add  ----IS_INTERFACE---- variable!!!!!! ERROR", "");

        //check that the domain size is correctly prescribed
        if (this->mdomain_size != msolver_config.GetDomainSize())
            KRATOS_ERROR(std::logic_error, "domain size not coinciding", "")

            //verify buffer size
            if (BaseType::GetModelPart().GetBufferSize() < mtime_order + 1)
                KRATOS_ERROR(std::logic_error, "insufficient buffer size. Buffer size should be >= time_order+1", "");

        //check that, in the 2D case, the xy plane is used.
        if (this->mdomain_size == 2)
        {
            double zmin = BaseType::GetModelPart().NodesBegin()->Z();
            double zmax = zmin;
            for (ModelPart::NodeIterator i = BaseType::GetModelPart().NodesBegin();
                    i != BaseType::GetModelPart().NodesEnd(); ++i)
            {
                if (i->Z() < zmin) zmin = i->Z();
                else if (i->Z() > zmax) zmax = i->Z();
            }
            if (fabs(zmax - zmin) > 1e-20)
                KRATOS_ERROR(std::logic_error, "2D model is not in the XY plane!", "")
            }

        //verify element type, check that the Id is non zero, and calls the Check function for all of the elements
        if (this->mdomain_size == 2)
        {
            const char ElementName[] = "Fluid2D";
            Element const& ref_el = KratosComponents<Element>::Get(ElementName);

            const char ElementName2[] = "Fluid2Dlevelset";
            Element const& ref_el2 = KratosComponents<Element>::Get(ElementName2);

            for (ModelPart::ElementsContainerType::iterator it = BaseType::GetModelPart().ElementsBegin();
                    it != BaseType::GetModelPart().ElementsEnd(); ++it)
            {
                if (it->Id() < 1)
                    KRATOS_ERROR(std::logic_error, "Element Id can not be lesser than 1 (0 is not allowed as Id)", "");
                if (typeid (ref_el) != typeid (*it) && typeid (ref_el2) != typeid (*it))
                {
                    std::cout << "wrong element found --> " << it->Id() << std::endl;
                    KRATOS_ERROR(std::logic_error, "Fractional step strategy requires Fluid2D element for the 2D case", "");
                }
                it->Check(BaseType::GetModelPart().GetProcessInfo());
            }
        }
        else
        {
            const char ElementName[] = "Fluid3D";
            Element const& ref_el = KratosComponents<Element>::Get(ElementName);

            for (ModelPart::ElementsContainerType::iterator it = BaseType::GetModelPart().ElementsBegin();
                    it != BaseType::GetModelPart().ElementsEnd(); ++it)
            {
                if (it->Id() < 1)
                    KRATOS_ERROR(std::logic_error, "Element Id can not be lesser than 1 (0 is not allowed as Id)", "");
                if (typeid (ref_el) != typeid (*it))
                {
                    std::cout << "wrong element found --> " << it->Id() << std::endl;
                    KRATOS_ERROR(std::logic_error, "Fractional step strategy requires Fluid3D element for the 3D case", "");
                }
                it->Check(BaseType::GetModelPart().GetProcessInfo());
            }

        }

        return 0;
        */
        
        KRATOS_CATCH("")
    }
    
    void InitializeFractionalStep(const int aStep, const int aTimeOrder)
    {
        KRATOS_TRY;
        
        KRATOS_CATCH("");
    }
    
    void AssignInitialStepValues() 
    {
        KRATOS_TRY
       
        
        KRATOS_CATCH("");
    }
    
    void PredictVelocity(int step, int prediction_order)
    {
        KRATOS_TRY
 
        KRATOS_CATCH("");
    }
    
protected:
    
    typename BaseType::Pointer mPressureStrategy; 
    typename BaseType::Pointer mConcentrationStrategy; 

    double mPressureTol; 
    double mConcentrationTol;
    int mMaxIterPressure; 
    int mMaxIterConcentration; 
    unsigned int mTimeOrder;
    unsigned int mPredictorOrder; 
    bool mPredictorCorrector; 
    bool mReformDofAtEachIteration;
    int mEchoLevel; 

private:    
    //Dubbio
    unsigned int mStep;
    unsigned int mDomainSize; 
    
    //Doc -> mSolverConfigAttribute    
    SolverStrategyConfiguration<TSparseSpace, TDenseSpace, TLinearSolver>& mSolverStrategyConfiguration;

    FractionalIterativeStrategy(const FractionalIterativeStrategy& Other);

}; /* Class FractionalIterativeStrategy */

} /* namespace Kratos.*/

#endif /* KRATOS_FRACTIONAL_ITERATIVE_STRATEGY  defined */

